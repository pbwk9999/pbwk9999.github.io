#!/var/jb/bin/sh
# --------------------------------------------------------------------------
# 没病窗口工具 · Activator 健康检查 / 自动修复（无根越狱：Dopamine / palera1n rootless）
#
# 掉 0 项的两个真正原因（表现一模一样，都是 `activator listeners` 从 261/294 项掉到 0）：
#   1) 兼容层自带的「连续重启保护」——SpringBoard 连着重启 5 次它就不再加载 Activator。
#      用户「连着注销几次」会被误判成崩溃环，这是最常见的一个。
#      治法：把它的计数 /var/jb/tmp/actfix.launches 清零，再注销一次就恢复。
#   2) /var/jb/basebin/.fakelib/ 那层「rootful 路径改写」在越狱重新引导时会重新生成、
#      条目会丢，Activator 核心就找不到自己的 bundle。
#      治法：补齐软链 / 权限 / 属主 / 缓存之后再注销一次。
# 另外：本脚本必须用 root 跑。`activator listeners` 用 mobile 跑只会读到空列表，
#       会被误判成「掉光了」，然后白注销用户好几次。
#
# 用法：
#   activator-fixup                查一次；有问题就修，需要时自动注销一次（默认）
#   activator-fixup --check        只查不修；退出码 0 = 健康，1 = 有问题
#   activator-fixup --norespring   修，但绝不自动注销（安装脚本第一遍用这个）
# ---------------------------------------------------------------------------

# launchd 拉起这个脚本时，环境里的 PATH 只有 /usr/bin:/bin:/usr/sbin:/sbin，
# 而 date / grep / chmod 这些工具都在 /var/jb/usr/bin 下面。不先设好 PATH，
# 脚本会以「date: not found」这类方式半途静默失败（修完等于没修）。
PATH=/var/jb/usr/bin:/var/jb/bin:/var/jb/usr/sbin:/var/jb/sbin:/usr/bin:/bin:/usr/sbin:/sbin
export PATH

JB=/var/jb
FL=$JB/basebin/.fakelib
ACT=$JB/usr/bin/activator
KILL=$JB/usr/bin/killall
LOG=$JB/tmp/activator-fixup.log
LOCK=$JB/tmp/activator-fixup.lock
STAMP=$JB/tmp/activator-fixup.lastrespring
FAILS=$JB/tmp/activator-fixup.resprings

MIN_LISTENERS=20          # 少于这个数就算「注册掉光了」（正常是 200 以上）
RESPRING_COOLDOWN=120     # 两次自动注销之间至少隔 2 分钟
MAX_RESPRINGS=3           # 连着自动注销这么多次还不好，就别再折腾用户了，只记日志
ACTCNT=$JB/tmp/actfix.launches    # 兼容层的「SpringBoard 连续重启」计数
ACTLOG=$JB/tmp/actfix.log         # 兼容层自己写的日志

# 健康检查这个 launchd 任务的坐标（它才是「掉动作」的兜底）
WD_LABEL=com.rpetrich.activator.fakelib
WD_PLIST=$JB/Library/LaunchDaemons/$WD_LABEL.plist
WD_DOMAIN=user/$(id -u mobile 2> /dev/null || echo 501)

MODE=fix
for a in "$@"; do
	case "$a" in
		--check)      MODE=check ;;
		--norespring) MODE=norespring ;;
	esac
done

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') uid=$(id -u 2>/dev/null) $*" >> $LOG 2>/dev/null || true; }

# 必须 root：修 .fakelib 要写 root 的目录；mobile 跑 activator listeners 又读不准。
if [ "$(id -u 2>/dev/null)" != "0" ]; then
	STAMP=$JB/tmp/activator-fixup.nonroot
	NOW=$(date +%s)
	LAST=$(cat $STAMP 2> /dev/null || echo 0)
	if [ $((NOW - LAST)) -gt 3600 ]; then
		echo $NOW > $STAMP 2> /dev/null || true
		echo "activator-fixup: 被 uid=$(id -u) 拉起，跳过（修 .fakelib 需要 root）" >&2
	fi
	exit 0
fi

listen_dump()  { $ACT listeners 2>/dev/null; }
listen_count() { listen_dump | grep -c '[^[:space:]]'; }

# 健康 = 列表读得出来、条数够、而且我们自己那两个动作在
healthy() {
	D=$(listen_dump)
	[ -n "$D" ] || return 1
	N=$(printf '%s\n' "$D" | grep -c '[^[:space:]]')
	[ "$N" -ge "$MIN_LISTENERS" ] || return 1
	printf '%s\n' "$D" | grep -q 'jp\.zetsu\.showhidden'   || return 1
	printf '%s\n' "$D" | grep -q 'jp\.zetsu\.launchwinodw' || return 1
	return 0
}

# ---- 修：1) rootful 路径改写的软链（越狱重新引导后会丢） ----
lnk() {
	if [ ! -e "$FL/$1" ] && [ ! -L "$FL/$1" ]; then
		ln -s "$2" "$FL/$1" 2> /dev/null || true
	fi
}

fix_links() {
	mkdir -p $FL 2> /dev/null || true
	lnk libactivator.dylib /var/jb/usr/lib/libactivator.dylib
	lnk Activator /var/jb/Library/Activator
	lnk Activator.app /var/jb/Applications/Activator.app
	lnk librocketbootstrap.dylib /var/jb/usr/lib/librocketbootstrap.dylib
	lnk libsubstrate.dylib /var/jb/usr/lib/libsubstrate.dylib
	lnk libellekit.dylib /var/jb/usr/lib/libellekit.dylib
	lnk libhooker.dylib /var/jb/usr/lib/libhooker.dylib
	lnk libblackjack.dylib /var/jb/usr/lib/libblackjack.dylib
	lnk libprefs.dylib /var/jb/usr/lib/libprefs.dylib
	lnk TweakInject.dylib /var/jb/usr/lib/TweakInject.dylib
	lnk TweakLoader.dylib /var/jb/usr/lib/TweakLoader.dylib
	lnk Switches /var/jb/Library/Switches
	lnk PreferenceLoader /var/jb/Library/PreferenceLoader
	lnk MobileSubstrate /var/jb/Library/MobileSubstrate
}

# ---- 修：2) 可执行权限 / 被禁用的标记 / 缺的加载器 ----
fix_perms() {
	chmod 755 $JB/usr/lib/libactivator.dylib 2> /dev/null || true
	chmod 755 $JB/usr/bin/activator 2> /dev/null || true
	chmod 755 $JB/usr/lib/TweakInject/Activator.dylib 2> /dev/null || true
	chmod 755 $JB/Applications/Activator.app/Activator 2> /dev/null || true
	chmod 755 $JB/Library/Activator/ActivatorSpringBoard.bundle/ActivatorSpringBoard 2> /dev/null || true
	chmod 755 $JB/Library/Activator/LibActivator.bundle/LibActivator 2> /dev/null || true
	chmod 644 $JB/usr/lib/TweakInject/Activator.plist 2> /dev/null || true
	chown -h root:wheel $JB/Library/PreferenceBundles/LibActivator.bundle 2> /dev/null || true
	chown root:wheel $JB/Library/LaunchDaemons/com.rpetrich.activator.fakelib.plist 2> /dev/null || true
	# 被谁禁用过就放回来
	rm -f $JB/usr/lib/TweakInject/Activator.dylib.disabled $JB/usr/lib/TweakInject/Activator.disabled 2> /dev/null || true
	if [ -L $JB/Library/MobileSubstrate/DynamicLibraries/Activator.dylib ]; then
		rm -f $JB/Library/MobileSubstrate/DynamicLibraries/Activator.dylib 2> /dev/null || true
	fi
	if [ ! -f "$JB/usr/lib/TweakInject/PreferenceLoader.dylib" ] && [ -f $JB/usr/lib/activator-support/PreferenceLoader.dylib ]; then
		cp -f $JB/usr/lib/activator-support/PreferenceLoader.dylib "$JB/usr/lib/TweakInject/PreferenceLoader.dylib" 2> /dev/null || true
		cp -f $JB/usr/lib/activator-support/PreferenceLoader.plist "$JB/usr/lib/TweakInject/PreferenceLoader.plist" 2> /dev/null || true
		chmod 755 "$JB/usr/lib/TweakInject/PreferenceLoader.dylib" 2> /dev/null || true
	fi
}

# ---- 修：3) Activator 的用户态文件必须是 mobile 的 ----
# 只要有人用 root 跑过 activator（比如售后排错时 sudo activator listeners），
# 这些文件就可能变成 root 拥有；SpringBoard 里的 Activator 写不进去就起不来。
# 这几条很便宜，所以每次跑都顺手做一遍。
fix_owner() {
	mkdir -p /var/mobile/Library/Caches/libactivator 2> /dev/null || true
	touch /var/mobile/Library/Caches/libactivator.plist 2> /dev/null || true
	chown mobile /var/mobile/Library/Caches 2> /dev/null || true
	chown -R mobile /var/mobile/Library/Caches/libactivator 2> /dev/null || true
	chown mobile /var/mobile/Library/Caches/libactivator.plist 2> /dev/null || true
	chmod 666 /var/mobile/Library/Caches/libactivator.plist 2> /dev/null || true
	# SpringBoard 是 mobile 身份在跑；日志若是 root 644，它的记录写不进来，
	# 「连续重启保护被触发」就永远发现不了，只能看着动作掉成 0 项。
	[ -f "$ACTLOG" ] || : > "$ACTLOG" 2> /dev/null || true
	chmod 666 "$ACTLOG" 2> /dev/null || true
	chown mobile "$ACTCNT" 2> /dev/null || true
	chmod 644 "$ACTCNT" 2> /dev/null || true
	for p in /var/mobile/Library/Preferences/com.rpetrich.activator.plist \
	         /var/mobile/Library/Preferences/libactivator.plist; do
		if [ -e "$p" ]; then chown mobile "$p" 2> /dev/null || true; fi
	done
}

# ---- 修：6) 开箱即用（新装的机器没人手动配也应当能用） ----
# a) 引擎的开关 kEnabled。这个键缺了的时候，引擎把自己当成「没启用」：
#    收到事件也不建窗，用户看到的就是「装好了但没反应」。
# b) 两个手势默认是空的。绑一次就好，绑过了就不再动用户的配置。
ensure_user_defaults() {
	ZP=/var/jb/var/mobile/Library/Preferences/jp.dcsyhi.zetsu.plist
	mkdir -p /var/jb/var/mobile/Library/Preferences 2> /dev/null || true
	if [ ! -f "$ZP" ] || ! grep -q kEnabled "$ZP" 2> /dev/null; then
		# 已有但不带 kEnabled 的，先留一份备份再补，别把用户别的设置悄悄丢掉
		[ -f "$ZP" ] && cp -f "$ZP" "$ZP.before_defaults" 2> /dev/null || true
		cat > $JB/tmp/zetsu-defaults.plist <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>kEnabled</key>
	<true/>
	<key>kRatio</key>
	<integer>1</integer>
</dict>
</plist>
PLIST
		cp -f $JB/tmp/zetsu-defaults.plist "$ZP" 2> /dev/null || true
		chown mobile "$ZP" 2> /dev/null || true
		chmod 600 "$ZP" 2> /dev/null || true
		log "引擎开关 kEnabled 缺失，已补上默认值"
	fi
	[ -x "$ACT" ] || return 0
	# 服务没起来的时候先不动，免得每 2 分钟白试一次
	[ -n "$($ACT current-mode 2> /dev/null)" ] || return 0
	if [ -z "$($ACT get libactivator.motion.shake 2> /dev/null)" ]; then
		$ACT set libactivator.motion.shake jp.zetsu.launchwinodw > /dev/null 2>&1 || true
		log "手势未绑定，已补：摇一摇 -> 创建窗口"
	fi
	if [ -z "$($ACT get libactivator.statusbar.tap.double.right 2> /dev/null)" ]; then
		$ACT set libactivator.statusbar.tap.double.right jp.zetsu.showhidden > /dev/null 2>&1 || true
		log "手势未绑定，已补：状态栏右侧双击 -> 显示/隐藏"
	fi
}

# ---- 修：4) 越狱重新引导后 trustcache 会清空，Activator 的可执行文件要重新登记 ----
fix_tc() {
	if [ ! -x $JB/basebin/jbctl ]; then return 0; fi
	for H in 61A332B0B81892757EF0E6543BF4A4B82DA35F30 59D5FEF184E43627C9D1089A044ABE47F07823BC 7E3845B6AE1149BC757FE5B2F208A00CC7006FB9 C8AEB0D7B37C56404CBC74D2C2E080FDAFBB7750 AAA48DC39B897D46553281E22F08107C43DD27F3 7959275A8D002AEDAC7C6ADAB06940D9C58613EF FD58374117C1D73E9CF664D0DD8CE0A4DBD680CE DCA5D72E4ADDBA78C346A76841E475FD5664CE2E 589C83C44AE9B8201FF105B209860FF17DBC7666 562C8ECB11044A787D9355E726CB4C30D5E2B9D2 8FCC4C9200FB43C1B876E37728AA667A3D02F598 AA9E71FD93C83F1AF4ABF6662B9606B72304DE50 74770B9E16E29EC03B54C825229536782DCB6274 FE2BEF2A7897718CD41BB399E1A2A7A58E8CA586; do
		$JB/basebin/jbctl trustcache add "$H" > /dev/null 2>&1 || true
	done
}

respring_ok() {
	NOW=$(date +%s)
	LAST=$(cat $STAMP 2> /dev/null || echo 0)
	if [ $((NOW - LAST)) -lt $RESPRING_COOLDOWN ]; then return 1; fi
	N=$(cat $FAILS 2> /dev/null || echo 0)
	if [ "$N" -ge "$MAX_RESPRINGS" ]; then return 1; fi
	return 0
}

# ---- 兼容层的「连续重启保护」 ----
# 无根兼容层（TweakInject/Activator.dylib）里带了个自我保护：SpringBoard 连着重启 5 次
# 就不再加载 Activator，怕用户陷在崩溃环里。可它把「手动连着注销几次」也当成崩溃环了。
# 治法：把它的计数清零，下一次启动就照常加载。
actfix_tripped() {
	[ -f "$ACTLOG" ] || return 1
	L=$(grep -n '^--- start proc=SpringBoard' "$ACTLOG" 2> /dev/null | tail -1 | cut -d: -f1)
	[ -n "$L" ] || return 1
	tail -n +"$L" "$ACTLOG" 2> /dev/null | grep -q 'crash-loop guard tripped'
}

actfix_reset() {
	[ -e "$ACTCNT" ] || return 0
	printf '0' > "$ACTCNT" 2> /dev/null || true
}

# ---- 修：5) 「每 2 分钟健康检查」这个守护任务本身必须在线 ----
# 掉动作的兜底就是它。重装 / 重新引导之后它偶尔会没被 launchd 加载上，
# 这时没人发现、也没人补救（Activator 本身还是好的，所以健康检查会说「一切正常」）。
# 所以这一步放在健康检查之前：只要本脚本跑起来，就顺手确认它在线，不在就挂回去。
ensure_watchdog() {
	[ -f "$WD_PLIST" ] || return 0
	LC=
	# 无根越狱里 launchctl 在 /var/jb/usr/bin 下，真机 /usr/bin 里没有
	for c in /var/jb/usr/bin/launchctl /usr/bin/launchctl /bin/launchctl; do
		if [ -x "$c" ]; then LC=$c; break; fi
	done
	[ -n "$LC" ] || LC=launchctl
	if $LC print "$WD_DOMAIN/$WD_LABEL" > /dev/null 2>&1; then return 0; fi
	$LC bootstrap "$WD_DOMAIN" "$WD_PLIST" > /dev/null 2>&1 \
		|| $LC load -w "$WD_PLIST" > /dev/null 2>&1 || true
	if $LC print "$WD_DOMAIN/$WD_LABEL" > /dev/null 2>&1; then
		log "守护任务之前不在线，已重新挂上（$WD_LABEL）"
	else
		log "守护任务不在线，重新挂载没成功（$WD_LABEL）"
	fi
}

# ---- 用目录锁，避免两个实例同时改；锁超过 90 秒就当陈旧的抢过来 ----
TRIES=0
while ! mkdir $LOCK 2> /dev/null; do
	OLD=$(cat $LOCK/started 2> /dev/null || echo 0)
	NOW=$(date +%s)
	if [ $((NOW - OLD)) -gt 90 ]; then
		rm -rf $LOCK 2> /dev/null || true
		continue
	fi
	TRIES=$((TRIES + 1))
	if [ "$TRIES" -ge 20 ]; then exit 0; fi
	sleep 1
done
date +%s > $LOCK/started 2> /dev/null || true
trap 'rm -rf $LOCK 2> /dev/null || true' EXIT INT TERM HUP

[ -x $ACT ] || exit 0

fix_owner        # 便宜，每次都做
[ "$MODE" = "check" ] || ensure_user_defaults

# 守护任务要在健康检查之前确认：Activator 好的时候这个脚本会立刻 exit，
# 放后面就永远轮不到它。--check 是只读模式，不碰。
if [ "$MODE" != "check" ]; then ensure_watchdog; fi

if healthy; then
	rm -f $FAILS 2> /dev/null || true
	[ "$MODE" = "fix" ] && log "health ok, listeners=$(listen_count)"
	exit 0
fi

if [ "$MODE" = "check" ]; then
	log "health BAD, listeners=$(listen_count)"
	exit 1
fi

log "health BAD (listeners=$(listen_count)), repairing"

# 最常见的原因：兼容层的连续重启保护被「手动注销几次」触发了
if actfix_tripped; then
	actfix_reset
	log "兼容层连续重启保护被触发（掉到 0 项的元凶），计数已清零"
fi

# 刚开机可能只是还没登记，给它一点时间
sleep 8
if healthy; then
	rm -f $FAILS 2> /dev/null || true
	log "just slow, now ok"
	exit 0
fi

fix_links
if [ ! -e "$FL/dyld" ]; then
	N=0
	while [ $N -lt 12 ]; do
		[ -e "$FL/dyld" ] && break
		N=$((N + 1))
		sleep 5
	done
	fix_links
fi
fix_perms
fix_tc
if [ -x $JB/usr/bin/uicache ]; then $JB/usr/bin/uicache -a > /dev/null 2>&1 || true; fi
sleep 3

if healthy; then
	rm -f $FAILS 2> /dev/null || true
	log "repaired, no respring needed (listeners=$(listen_count))"
	exit 0
fi

if [ "$MODE" = "norespring" ]; then
	log "still bad, listeners=$(listen_count) (respring skipped)"
	exit 1
fi
if ! respring_ok; then
	log "still bad, listeners=$(listen_count) (respring skipped: cooldown)"
	exit 1
fi

# 东西都补齐了还是不行 -> 注销一次，让 SpringBoard 重新加载 Activator。
# 这里故意不在原地等：注销会把这一轮进程一起带走，等也等不到；复查交给下一轮
# （fakelib 守护每 2 分钟自己跑一次，安装脚本注销后也会跑一次），健康时会把计数清零。
# 冷却 4 分钟、最多连着注销 3 次，不会没完没了地折腾用户。
date +%s > $STAMP 2> /dev/null || true
echo $(( $(cat $FAILS 2> /dev/null || echo 0) + 1 )) > $FAILS 2> /dev/null || true
log "still bad -> respring to reload Activator (listeners=$(listen_count)); 下一轮复查"
# 注销会把这一轮进程一起带走，所以先主动把锁放掉，别让下一次跑的时候被自己的锁挡住
rm -rf $LOCK 2> /dev/null || true
$KILL -9 SpringBoard > /dev/null 2>&1 || killall -9 SpringBoard > /dev/null 2>&1 || true
exit 0